//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: QP_CA_Codegen_data.cpp
//
// Code generated for Simulink model 'QP_CA_Codegen'.
//
// Model version                  : 1.3
// Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
// C/C++ source code generated on : Mon Dec 23 15:44:19 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "QP_CA_Codegen.h"

// Constant parameters (default storage)
const QP_CA_Codegen::ConstP rtConstP{
  // Expression: [1 1 1 1 1 1; 0.275 -0.275 0.1375 -0.1375 -0.1375 0.1375; 0 0 0.2382 -0.2382 0.2382 -0.2382; -0.1 0.1 -0.1 0.1 -0.1 0.1]
  //  Referenced by: '<Root>/Constant1'

  { 1.0, 0.275, 0.0, -0.1, 1.0, -0.275, 0.0, 0.1, 1.0, 0.1375, 0.2382, -0.1, 1.0,
    -0.1375, -0.2382, 0.1, 1.0, -0.1375, 0.2382, -0.1, 1.0, 0.1375, -0.2382, 0.1
  }
};

//
// File trailer for generated code.
//
// [EOF]
//
